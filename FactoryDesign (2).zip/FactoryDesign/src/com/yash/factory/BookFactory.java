package com.yash.factory;

import com.yash.helper.CodingBookHelper;
import com.yash.helper.HorrorBookHelper;
import com.yash.helper.MySteryBookHelper;
import com.yash.helper.RomanticBookHelper;
import com.yash.ifactory.iBookCategory;

public class BookFactory {

	public static iBookCategory getInstance(String type) {
		String Type = type.toUpperCase();
		switch (Type) {
		case "CODING":
			return new CodingBookHelper();
		case "HORROR":
			return new HorrorBookHelper();
		case "MYSTERY":
			return new MySteryBookHelper();
		case "ROMANTIC":
			return new RomanticBookHelper();

		}
		return null;
	}
}
