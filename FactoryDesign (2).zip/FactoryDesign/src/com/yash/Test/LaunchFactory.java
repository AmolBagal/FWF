package com.yash.Test;

public class LaunchFactory {
	public static void main(String[] args) {
		BookTest.launchFactory();
	}
}
