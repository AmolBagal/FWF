package com.yash.helper;

import java.util.List;

import com.yash.data.GetBooks;
import com.yash.data.ShowBooks;
import com.yash.ifactory.iBookCategory;
import com.yash.library.model.Book;

public class RomanticBookHelper implements iBookCategory {

	@Override
	public Book getBookNames(int id) {
		ShowBooks.showRomanticBookList();
		return GetBooks.getRomanticBook(id);
	}

}
